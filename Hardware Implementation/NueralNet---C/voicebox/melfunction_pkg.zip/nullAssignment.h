/*
 * File: nullAssignment.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 17-Apr-2018 03:49:35
 */

#ifndef NULLASSIGNMENT_H
#define NULLASSIGNMENT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void b_nullAssignment(emxArray_real_T *x, int idx);
extern void nullAssignment(emxArray_real_T *x);

#endif

/*
 * File trailer for nullAssignment.h
 *
 * [EOF]
 */
