/*
 * File: filter.c
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 17-Apr-2018 03:49:35
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "melfunction.h"
#include "filter.h"
#include "melfunction_emxutil.h"

/* Function Definitions */

/*
 * Arguments    : const emxArray_real_T *x
 *                emxArray_real_T *y
 * Return Type  : void
 */
void filter(const emxArray_real_T *x, emxArray_real_T *y)
{
  short x_idx_0;
  int k;
  int nx;
  int loop_ub;
  int naxpy;
  x_idx_0 = (short)x->size[0];
  k = y->size[0];
  y->size[0] = x_idx_0;
  emxEnsureCapacity_real_T1(y, k);
  nx = x->size[0];
  loop_ub = y->size[0];
  k = y->size[0];
  y->size[0] = loop_ub;
  emxEnsureCapacity_real_T1(y, k);
  for (k = 0; k < loop_ub; k++) {
    y->data[k] = 0.0;
  }

  if (x->size[0] >= 2) {
    for (loop_ub = 0; loop_ub < nx; loop_ub++) {
      y->data[loop_ub] += 0.0625 * x->data[loop_ub];
    }
  } else {
    naxpy = x->size[0];
    k = 1;
    while (k <= nx) {
      for (loop_ub = 1; loop_ub <= naxpy; loop_ub++) {
        y->data[0] += x->data[0] * 0.0625;
      }

      naxpy--;
      k = 2;
    }
  }
}

/*
 * File trailer for filter.c
 *
 * [EOF]
 */
