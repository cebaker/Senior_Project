/*
 * File: melfunction.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 17-Apr-2018 03:49:35
 */

#ifndef MELFUNCTION_H
#define MELFUNCTION_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void melfunction(const emxArray_real_T *x, double c[24]);

#endif

/*
 * File trailer for melfunction.h
 *
 * [EOF]
 */
