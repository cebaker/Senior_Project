/*
 * File: melfunction.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:21:24
 */

#ifndef MELFUNCTION_H
#define MELFUNCTION_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void melfunction(const double x[16000], double c[24]);

#endif

/*
 * File trailer for melfunction.h
 *
 * [EOF]
 */
