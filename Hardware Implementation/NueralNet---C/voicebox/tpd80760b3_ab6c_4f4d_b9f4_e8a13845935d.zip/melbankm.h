/*
 * File: melbankm.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:21:24
 */

#ifndef MELBANKM_H
#define MELBANKM_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void melbankm(emxArray_real_T *x_d, emxArray_int32_T *x_colidx,
                     emxArray_int32_T *x_rowidx);

#endif

/*
 * File trailer for melbankm.h
 *
 * [EOF]
 */
