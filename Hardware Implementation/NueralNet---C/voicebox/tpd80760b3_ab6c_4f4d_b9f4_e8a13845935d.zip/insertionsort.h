/*
 * File: insertionsort.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:21:24
 */

#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void insertionsort(emxArray_int32_T *x, int xstart, int xend, const
  cell_wrap_1 cmp_tunableEnvironment[2]);

#endif

/*
 * File trailer for insertionsort.h
 *
 * [EOF]
 */
