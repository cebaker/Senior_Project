/*
 * File: melfunction_initialize.c
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:17:32
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "melfunction.h"
#include "melfunction_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void melfunction_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for melfunction_initialize.c
 *
 * [EOF]
 */
