/*
 * File: melfunction_initialize.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:17:32
 */

#ifndef MELFUNCTION_INITIALIZE_H
#define MELFUNCTION_INITIALIZE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void melfunction_initialize(void);

#endif

/*
 * File trailer for melfunction_initialize.h
 *
 * [EOF]
 */
