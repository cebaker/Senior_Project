/*
 * File: melfunction_terminate.c
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:17:32
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "melfunction.h"
#include "melfunction_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void melfunction_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for melfunction_terminate.c
 *
 * [EOF]
 */
