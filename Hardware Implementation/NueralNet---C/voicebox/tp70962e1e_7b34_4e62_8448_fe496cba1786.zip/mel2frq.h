/*
 * File: mel2frq.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:17:32
 */

#ifndef MEL2FRQ_H
#define MEL2FRQ_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void mel2frq(const double mel[4], double frq[4]);

#endif

/*
 * File trailer for mel2frq.h
 *
 * [EOF]
 */
