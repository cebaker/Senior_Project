/*
 * File: log.h
 *
 * MATLAB Coder version            : 4.0
 * C/C++ source code generated on  : 12-Apr-2018 16:17:32
 */

#ifndef LOG_H
#define LOG_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "melfunction_types.h"

/* Function Declarations */
extern void b_log(double x[24]);

#endif

/*
 * File trailer for log.h
 *
 * [EOF]
 */
